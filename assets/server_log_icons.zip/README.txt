Discord application emoji pack for HromAssistant server logs

Upload the PNG files in the Discord Developer Portal under your application settings > Emojis. Keep each emoji name exactly the same as the PNG filename without the .png extension. The bot fetches application emojis automatically; no IDs need to be configured.

The original pack has 74 general action icons. manifest.csv maps those actions to their emoji name and Lucide source icon. manifest_detailed_actions.csv lists 18 additional icons for specific voice state and role grant/removal actions. Upload these additional PNGs too; the bot expects the exact names shown in the manifests. The updated full archive contains all 92 icons.

Discord allows up to 2000 emojis per application. Application emojis can be used by that application in its messages without the USE_EXTERNAL_EMOJIS permission. After uploading or changing emojis, restart the bot (or reconnect it) so it refreshes the application emoji list.

Icons use the Lucide icon set. See LICENSE for its license.
