Additional action-specific Discord application emojis

Upload these 18 PNGs in Developer Portal > your application > Emojis. They extend the original 74-icon pack; do not upload the original icons again.

Keep the emoji names exactly as the PNG filenames without ".png". The bot uses these names for separate self-mute/self-deaf changes, moderator mute/deaf changes, stream and camera start/stop, stage speaking status, and role grants/removals.

manifest_detailed_actions.csv maps action keys to emoji names and icon designs. The updated full manifest.csv contains all 92 actions.

After uploading, restart the bot. Voice self mute/deaf is logged separately from moderator mute/deaf. Moderator changes come from the audit log; Gateway copies of server mute/deaf are intentionally not logged to prevent duplicate messages.
